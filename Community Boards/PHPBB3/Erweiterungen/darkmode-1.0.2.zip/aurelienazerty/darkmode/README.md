# darkmode
This extension allows to switch to Light /Dark mode.
It's invert color with CSS. 