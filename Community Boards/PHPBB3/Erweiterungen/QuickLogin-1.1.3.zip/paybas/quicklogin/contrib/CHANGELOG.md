### Changelog

- 1.1.3 (25/07/2020)
  - [CHG] html twig syntax  
- 1.1.2 (08/07/2020)
  - [CHG] repackaged, update urls  
- 1.1.0 (17/09/2017)
  - [FIX] update for phpBB 3.2
- 1.1.1 (01/10/2017)
  - [FIX] listener fixes
  - [NEW] support pbwow3