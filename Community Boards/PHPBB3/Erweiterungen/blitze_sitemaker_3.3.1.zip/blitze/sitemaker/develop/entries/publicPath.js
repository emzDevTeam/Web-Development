import 'core-js/features/promise';

// eslint-disable-next-line
__webpack_public_path__ = `${window.config.scriptPath}ext/blitze/sitemaker/styles/all/theme/assets/`;
