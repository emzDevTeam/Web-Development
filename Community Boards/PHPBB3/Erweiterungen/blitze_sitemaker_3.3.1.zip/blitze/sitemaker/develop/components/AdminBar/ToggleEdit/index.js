import Button from '../../Button/button';

export default function ToggleEdit() {
	Button('#toggle-edit');
}
